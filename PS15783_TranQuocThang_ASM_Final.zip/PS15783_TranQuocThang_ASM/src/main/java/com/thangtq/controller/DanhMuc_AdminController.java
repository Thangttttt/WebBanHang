package com.thangtq.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.thangtq.dao.CategoryDAO;
import com.thangtq.entity.Category;

@Controller
public class DanhMuc_AdminController {
	
}
